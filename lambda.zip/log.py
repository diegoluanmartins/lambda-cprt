def log(message):
    print('Logging: ', message)